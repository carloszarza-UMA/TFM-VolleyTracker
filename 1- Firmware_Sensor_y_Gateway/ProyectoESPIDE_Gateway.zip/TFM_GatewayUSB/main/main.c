// =========================================================
// Código fuente del TFM: Sistema wearable IoT basado en Edge AI para la monitorización de saltos en voleibol
//
// Código del gateway, que sirve de puente entre los sensores (ESP-NOW) y la app interfaz (USB/UART)
//
// Autor: Carlos Zarza
// =========================================================

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_wifi.h"
#include "esp_now.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "driver/usb_serial_jtag.h"
#include "protocol.h"

static const char *TAG = "GATEWAY";

// MAC Broadcast
uint8_t broadcast_mac[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

QueueHandle_t esp_now_queue;
bool scanner_mode = false;

typedef struct {
    uint8_t mac_src[6];
    uint8_t data[250];
    int data_len;
} esp_now_queue_item_t;

// =========================================================
// CALLBACK ESP-NOW RECEPCIÓN: Lee comando y lo encola
// =========================================================
void on_recv(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
    esp_now_queue_item_t item;
    memcpy(item.mac_src, info->src_addr, 6);
    memcpy(item.data, data, len);
    item.data_len = len;
    xQueueSendFromISR(esp_now_queue, &item, NULL);
}

// =========================================================
// TAREA 1 - USB UART TX: Enviar JSON a app
// =========================================================
void usb_tx_task(void *pvParameters) {
    esp_now_queue_item_t item;
    while (1) {
        if (xQueueReceive(esp_now_queue, &item, portMAX_DELAY)) {
            uint8_t cmd = item.data[0];
            // Balizas sensores
            if (cmd == CMD_HELLO && scanner_mode) {
                printf("{\"event\":\"new_node\", \"mac\":\"%02X:%02X:%02X:%02X:%02X:%02X\"}\n",
                       item.mac_src[0], item.mac_src[1], item.mac_src[2],
                       item.mac_src[3], item.mac_src[4], item.mac_src[5]);
			// Salto detectado
            } else if (cmd == CMD_JUMP_DATA) {
                if (item.data_len == sizeof(msg_jump_t)) {
                    msg_jump_t *jump = (msg_jump_t *)item.data;
                    printf("{\"id\":%d, \"h\":%d}\n", jump->player_id, jump->height_cm);
                }
            }
        }
    }
}

// =========================================================
// TAREA 2 - USB UART RX: Lectura de comandos de la app
// =========================================================
void usb_rx_task(void *pvParameters) {
    char line[128];
    int pos = 0;
    uint8_t rx_buf[1];

    while (1) {
        int rxBytes = usb_serial_jtag_read_bytes(rx_buf, 1, pdMS_TO_TICKS(20));

        if (rxBytes > 0) {
            char c = (char)rx_buf[0];

            if (c == '\n' || c == '\r') {
                line[pos] = '\0';

                if (pos > 0) {
                	// Comienzo de escaneo de sensores
                    if (strncmp(line, "SCAN", 4) == 0) {
                        scanner_mode = true;
                        printf("{\"status\":\"scanner_on\"}\n");
                    }
                    // Asignacion de dorsales y MAC a sensores
                    else if (strncmp(line, "ASSIGN", 6) == 0) {
                        int m[6], assigned_id;
                        if (sscanf(line, "ASSIGN %x:%x:%x:%x:%x:%x %d",
                                   &m[0], &m[1], &m[2], &m[3], &m[4], &m[5], &assigned_id) == 7) {

                            uint8_t peer_mac[6];
                            for(int i=0; i<6; i++) peer_mac[i] = (uint8_t)m[i];

                            esp_now_peer_info_t peerInfo;
                            memset(&peerInfo, 0, sizeof(peerInfo));
                            memcpy(peerInfo.peer_addr, peer_mac, 6);
                            esp_now_add_peer(&peerInfo);

                            msg_assign_t assign_msg;
                            assign_msg.cmd = CMD_ASSIGN_ID;
                            assign_msg.player_id = (uint8_t)assigned_id;
                            esp_now_send(peer_mac, (uint8_t *)&assign_msg, sizeof(assign_msg));
                            esp_now_del_peer(peer_mac);

                            printf("{\"status\":\"assigned\", \"id\":%d}\n", assigned_id);
                        }
                    }
                    // Comienzo de medición
                    else if (strncmp(line, "START", 5) == 0) {
                        msg_simple_cmd_t start_msg;
                        start_msg.cmd = CMD_START_REC;
                        esp_now_send(broadcast_mac, (uint8_t *)&start_msg, sizeof(start_msg));
                        printf("{\"status\":\"started\"}\n");
                    }
                    // Finalización de medición
                    else if (strncmp(line, "STOP", 4) == 0) {
                        msg_simple_cmd_t stop_msg;
                        stop_msg.cmd = CMD_STOP_REC;
                        esp_now_send(broadcast_mac, (uint8_t *)&stop_msg, sizeof(stop_msg));
                        printf("{\"status\":\"stopped\"}\n");
                    }
                }
                pos = 0;
            }
            else if (pos < sizeof(line) - 1) {
                line[pos++] = c;
            }
        }
    }
}


// =========================================================
// BUCLE MAIN
// =========================================================
void app_main(void) {
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    usb_serial_jtag_driver_config_t usb_config = {
        .rx_buffer_size = 256,
        .tx_buffer_size = 256,
    };
    usb_serial_jtag_driver_install(&usb_config);

    esp_netif_init();
    esp_event_loop_create_default();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);
    esp_wifi_set_mode(WIFI_MODE_STA);
    esp_wifi_start();

    esp_now_init();
    esp_now_register_recv_cb(on_recv);

    esp_now_peer_info_t broadcast_peer;
    memset(&broadcast_peer, 0, sizeof(broadcast_peer));
    memcpy(broadcast_peer.peer_addr, broadcast_mac, 6);
    esp_now_add_peer(&broadcast_peer);

    esp_now_queue = xQueueCreate(50, sizeof(esp_now_queue_item_t));

    ESP_LOGI(TAG, "Gateway Inicializado.");

    xTaskCreate(usb_tx_task, "USB_TX", 8192, NULL, 5, NULL);
    xTaskCreate(usb_rx_task, "USB_RX", 8192, NULL, 5, NULL);
}
