// =========================================================
// Código fuente del TFM: Sistema wearable IoT basado en Edge AI para la monitorización de saltos en voleibol
//
// Protocolo de comunicación, con estructuras para el intercambio de datos entre sensores y gateway
//
// Autor: Carlos Zarza
// =========================================================

#pragma once
#include <stdint.h>

#define CMD_HELLO       0x01  // Sensor -> Gateway: Baliza
#define CMD_ASSIGN_ID   0x02  // Gateway -> Sensor: Asignar dorsal
#define CMD_JUMP_DATA   0x03  // Sensor -> Gateway: Info. de salto detectado
#define CMD_START_REC   0x04  // Gateway -> Sensor: Inicio del modo medición
#define CMD_STOP_REC    0x05  // Gateway -> Sensor: Final del modo medición

typedef struct __attribute__((packed)) {
    uint8_t cmd;
    uint8_t mac[6];
} msg_hello_t;

typedef struct __attribute__((packed)) {
    uint8_t cmd;
    uint8_t player_id;
} msg_assign_t;

typedef struct __attribute__((packed)) {
    uint8_t cmd;
    uint8_t player_id;
    uint16_t height_cm;
} msg_jump_t;

typedef struct __attribute__((packed)) {
    uint8_t cmd;
} msg_simple_cmd_t;
