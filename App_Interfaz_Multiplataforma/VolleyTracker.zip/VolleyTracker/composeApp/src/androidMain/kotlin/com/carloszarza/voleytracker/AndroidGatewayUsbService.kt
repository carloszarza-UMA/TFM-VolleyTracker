package com.carloszarza.volleytracker

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log
import com.hoho.android.usbserial.driver.*
import com.hoho.android.usbserial.util.SerialInputOutputManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

class AndroidGatewayUsbService(private val context: Context) : GatewayUsbService {
    private val TAG = "GatewayUsbService"
    
    private val _events = MutableSharedFlow<GatewayEvent>(extraBufferCapacity = 100)
    override val events: SharedFlow<GatewayEvent> = _events.asSharedFlow()

    private val _connectionState = MutableStateFlow<GatewayConnectionState>(GatewayConnectionState.Disconnected)
    override val connectionState: StateFlow<GatewayConnectionState> = _connectionState.asStateFlow()

    private var serialPort: UsbSerialPort? = null
    private var ioManager: SerialInputOutputManager? = null
    private val ACTION_USB_PERMISSION = "com.carloszarza.volleytracker.USB_PERMISSION"
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val jsonParser = usbJson

    private var isRequestingPermission = false
    private val connectionLock = Any()
    private var isConnecting = false

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                ACTION_USB_PERMISSION -> {
                    synchronized(connectionLock) {
                        isRequestingPermission = false
                        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                        Log.i(TAG, "USB Permission result: $granted")
                        if (granted) findAndConnect()
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    Log.i(TAG, "USB Device Detached")
                    closeConnection()
                }
                UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                    Log.i(TAG, "USB Device Attached")
                    findAndConnect()
                }
            }
        }
    }

    init {
        val appContext = context.applicationContext
        val filter = IntentFilter(ACTION_USB_PERMISSION).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            appContext.registerReceiver(usbReceiver, filter)
        }

        scope.launch {
            while (true) {
                if (_connectionState.value == GatewayConnectionState.Disconnected && !isRequestingPermission && !isConnecting) {
                    findAndConnect()
                }
                delay(5000)
            }
        }
    }

    private fun findAndConnect() {
        synchronized(connectionLock) {
            if (_connectionState.value is GatewayConnectionState.Connected || isConnecting) return
            
            val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
            val deviceList = manager.deviceList
            if (deviceList.isEmpty()) return

            val customTable = UsbSerialProber.getDefaultProbeTable().apply {
                addProduct(0x303A, 0x1001, CdcAcmSerialDriver::class.java)
                addProduct(0x303A, 0x1002, CdcAcmSerialDriver::class.java)
            }
            
            val prober = UsbSerialProber(customTable)
            val drivers = prober.findAllDrivers(manager)
            if (drivers.isEmpty()) return
            
            val driver = drivers[0]
            val device = driver.device

            if (manager.hasPermission(device)) {
                openSerialPort(driver)
            } else {
                if (!isRequestingPermission) {
                    isRequestingPermission = true
                    val intent = Intent(ACTION_USB_PERMISSION).apply { setPackage(context.packageName) }
                    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    } else {
                        PendingIntent.FLAG_UPDATE_CURRENT
                    }
                    val permissionIntent = PendingIntent.getBroadcast(context, 0, intent, flags)
                    manager.requestPermission(device, permissionIntent)
                }
            }
        }
    }

    private fun openSerialPort(driver: UsbSerialDriver) {
        synchronized(connectionLock) {
            if (serialPort?.isOpen == true || isConnecting) return
            isConnecting = true
            
            val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
            val connection = manager.openDevice(driver.device) ?: run {
                Log.e(TAG, "Failed to open USB connection")
                isConnecting = false
                return
            }
            
            val port = driver.ports[0]
            scope.launch(Dispatchers.IO) {
                try {
                    port.open(connection)
                    port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                    
                    try {
                        port.dtr = true
                        port.rts = true
                    } catch (e: Exception) {
                        Log.w(TAG, "DTR/RTS not supported: ${e.message}")
                    }
                    
                    delay(500)
                    
                    serialPort = port
                    _connectionState.value = GatewayConnectionState.Connected(driver.device.deviceName)
                    Log.i(TAG, "USB Connected: ${driver.device.deviceName}")

                    ioManager = SerialInputOutputManager(port, object : SerialInputOutputManager.Listener {
                        private val buffer = StringBuilder()
                        override fun onNewData(data: ByteArray) {
                            buffer.append(String(data, Charsets.UTF_8))
                            var index: Int
                            while (buffer.indexOf("\n").also { index = it } != -1) {
                                val line = buffer.substring(0, index).trim()
                                buffer.delete(0, index + 1)
                                if (line.isNotEmpty()) processLine(line)
                            }
                        }
                        override fun onRunError(e: Exception) { closeConnection() }
                    }).apply { 
                        readBufferSize = 16384
                        start() 
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Setup error: ${e.message}")
                    closeConnection()
                } finally {
                    synchronized(connectionLock) { isConnecting = false }
                }
            }
        }
    }

    private fun processLine(line: String) {
        try {
            Log.d(TAG, "<<< [RECV]: $line")
            val raw = jsonParser.decodeFromString<GatewayJson>(line)
            val event = when {
                raw.status == "scanner_on" -> GatewayEvent.ScannerOn
                raw.status == "started" -> GatewayEvent.Started
                raw.status == "stopped" -> GatewayEvent.Stopped
                raw.status == "assigned" -> GatewayEvent.Assigned(raw.id ?: 0)
                raw.event == "new_node" -> GatewayEvent.NewNode(raw.mac ?: "")
                raw.h != null -> GatewayEvent.Jump(raw.id ?: 0, raw.h)
                else -> null
            }
            event?.let { _events.tryEmit(it) }
        } catch (e: Exception) {}
    }

    private fun closeConnection() {
        synchronized(connectionLock) {
            ioManager?.stop()
            ioManager = null
            try { serialPort?.close() } catch (e: Exception) {}
            serialPort = null
            _connectionState.value = GatewayConnectionState.Disconnected
            isConnecting = false
            Log.i(TAG, "USB Disconnected")
        }
    }

    override suspend fun sendCommand(command: String) {
        withContext(Dispatchers.IO) {
            try {
                serialPort?.takeIf { it.isOpen }?.write(command.toByteArray(Charsets.UTF_8), 2000)
                Log.d(TAG, ">>> [SEND]: $command")
            } catch (e: Exception) {
                Log.e(TAG, "Send error: ${e.message}")
            }
        }
    }
}
