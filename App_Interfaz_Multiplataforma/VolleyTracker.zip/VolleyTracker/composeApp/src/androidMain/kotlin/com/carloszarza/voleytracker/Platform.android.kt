package com.carloszarza.volleytracker

import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AndroidPlatform : Platform {
    override val name: String = "Android ${Build.VERSION.SDK_INT}"
}

actual fun getPlatform(): Platform = AndroidPlatform()

class AndroidPersistenceManager : FilePersistenceManager {
    override suspend fun saveSession(fileName: String, data: String): Boolean {
        return try {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            
            val file = File(downloadsDir, "$fileName.csv")
            file.writeText(data)
            
            AndroidContext.get()?.let { context ->
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), null, null)
            }
            
            showToast("Archivo $fileName.csv guardado en Descargas")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    override suspend fun loadSession(): String? = null

    override fun showToast(message: String) {
        AndroidContext.get()?.let { context ->
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }
}

actual fun getPlatformPersistenceManager(): FilePersistenceManager = AndroidPersistenceManager()

actual object DateTimeProvider {
    actual fun getNowString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }
}

private var usbServiceInstance: GatewayUsbService? = null

actual fun getPlatformUsbService(): GatewayUsbService {
    val context = AndroidContext.get() ?: throw IllegalStateException("Android Context not initialized")
    if (usbServiceInstance == null) {
        usbServiceInstance = AndroidGatewayUsbService(context.applicationContext)
    }
    return usbServiceInstance!!
}
