package com.carloszarza.volleytracker

import android.content.Context
import java.lang.ref.WeakReference

object AndroidContext {
    private var contextRef: WeakReference<Context>? = null

    fun set(context: Context) {
        contextRef = WeakReference(context.applicationContext)
    }

    fun get(): Context? = contextRef?.get()
}
