package com.carloszarza.volleytracker

import com.fazecast.jSerialComm.SerialPort
import com.fazecast.jSerialComm.SerialPortDataListener
import com.fazecast.jSerialComm.SerialPortEvent
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import javax.swing.JFileChooser
import javax.swing.JOptionPane
import javax.swing.SwingUtilities
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.withContext

class JVMPlatform : Platform {
    override val name: String = "Java ${System.getProperty("java.version")}"
}

actual fun getPlatform(): Platform = JVMPlatform()

class JvmPersistenceManager : FilePersistenceManager {
    override suspend fun saveSession(fileName: String, data: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val userHome = System.getProperty("user.home")
            val downloadsDir = File(userHome, "Downloads")
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val file = File(downloadsDir, "$fileName.csv")
            file.writeText(data)
            showToast("Archivo ${file.name} guardado en Descargas")
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    override suspend fun loadSession(): String? = withContext(Dispatchers.IO) {
        var selectedData: String? = null
        withContext(Dispatchers.Main) {
            val chooser = JFileChooser()
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                selectedData = chooser.selectedFile.readText()
            }
        }
        selectedData
    }
    override fun showToast(message: String) {
        SwingUtilities.invokeLater {
            JOptionPane.showMessageDialog(null, message, "volleytracker", JOptionPane.INFORMATION_MESSAGE)
        }
    }
}

actual fun getPlatformPersistenceManager(): FilePersistenceManager = JvmPersistenceManager()

actual object DateTimeProvider {
    actual fun getNowString(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm").format(Date())
    }
}

/**
 * Implementación REAL para PC (JVM) usando jSerialComm.
 * Restaurada a la versión estable con Logs.
 */
class JvmGatewayUsbService : GatewayUsbService {
    private val _events = MutableSharedFlow<GatewayEvent>(extraBufferCapacity = 10)
    override val events: SharedFlow<GatewayEvent> = _events.asSharedFlow()
    private val _connectionState = MutableStateFlow<GatewayConnectionState>(GatewayConnectionState.Disconnected)
    override val connectionState: StateFlow<GatewayConnectionState> = _connectionState.asStateFlow()
    private var serialPort: SerialPort? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        scope.launch {
            while (true) {
                if (serialPort == null || !serialPort!!.isOpen) tryConnect()
                delay(2000)
            }
        }
    }

    private fun tryConnect() {
        val ports = SerialPort.getCommPorts()
        val targetPort = ports.find { 
            val d = it.descriptivePortName.uppercase()
            d.contains("USB") || d.contains("ESP") || d.contains("UART") || d.contains("CP210") || d.contains("CH34")
        } ?: return

        targetPort.baudRate = 115200
        targetPort.setComPortParameters(115200, 8, SerialPort.ONE_STOP_BIT, SerialPort.NO_PARITY)
        if (targetPort.openPort()) {
            serialPort = targetPort
            _connectionState.value = GatewayConnectionState.Connected(targetPort.systemPortName)
            targetPort.addDataListener(object : SerialPortDataListener {
                override fun getListeningEvents() = SerialPort.LISTENING_EVENT_DATA_AVAILABLE
                private var buffer = ""
                override fun serialEvent(event: SerialPortEvent) {
                    val p = event.serialPort
                    val available = p.bytesAvailable()
                    if (available > 0) {
                        val newData = ByteArray(available)
                        val numRead = p.inputStream.read(newData)
                        if (numRead > 0) {
                            buffer += String(newData, 0, numRead)
                            if (buffer.contains("\n")) {
                                val lines = buffer.split("\n")
                                for (i in 0 until lines.size - 1) {
                                    val line = lines[i].trim()
                                    if (line.isNotEmpty()) {
                                        println("<<< [USB RECV]: $line")
                                        processLine(line)
                                    }
                                }
                                buffer = lines.last()
                            }
                        }
                    }
                }
            })
        }
    }

    private fun processLine(line: String) {
        try {
            val raw = usbJson.decodeFromString<GatewayJson>(line)
            val event = when {
                raw.status == "scanner_on" -> GatewayEvent.ScannerOn
                raw.status == "started" -> GatewayEvent.Started
                raw.status == "stopped" -> GatewayEvent.Stopped
                raw.status == "assigned" -> GatewayEvent.Assigned(raw.id ?: 0)
                raw.event == "new_node" -> GatewayEvent.NewNode(raw.mac ?: "")
                raw.h != null -> GatewayEvent.Jump(raw.id ?: 0, raw.h)
                else -> null
            }
            event?.let { _events.tryEmit(it) }
        } catch (e: Exception) { }
    }

    private fun handleDisconnection() {
        if (serialPort != null) {
            serialPort?.removeDataListener()
            serialPort?.closePort()
            serialPort = null
        }
        _connectionState.value = GatewayConnectionState.Disconnected
    }

    override suspend fun sendCommand(command: String): Unit = withContext(Dispatchers.IO) {
        serialPort?.let {
            if (it.isOpen) {
                try {
                    print(">>> [USB SEND]: $command")
                    it.outputStream.write(command.toByteArray())
                    it.outputStream.flush()
                } catch (e: Exception) {
                    handleDisconnection()
                }
            }
        }
    }
}

actual fun getPlatformUsbService(): GatewayUsbService = JvmGatewayUsbService()
