package com.carloszarza.volleytracker

import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

fun main() = application {
    Window(
        onCloseRequest = ::exitApplication,
        title = "volleytracker",
    ) {
        App(DatabaseBuilderFactory())
    }
}
