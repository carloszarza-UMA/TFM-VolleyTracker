package com.carloszarza.volleytracker

interface FilePersistenceManager {
    suspend fun saveSession(fileName: String, data: String): Boolean
    suspend fun loadSession(): String?
    fun showToast(message: String)
}

expect fun getPlatformPersistenceManager(): FilePersistenceManager
