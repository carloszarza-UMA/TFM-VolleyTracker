package com.carloszarza.volleytracker

import kotlinx.serialization.Serializable

@Serializable
data class Salto(
    val dorsal: Int,
    val alturaCm: Int,
    val numeroSalto: Int
)
