package com.carloszarza.volleytracker

import androidx.room.RoomDatabase

expect class DatabaseBuilderFactory {
    fun create(): RoomDatabase.Builder<AppDatabase>
}
