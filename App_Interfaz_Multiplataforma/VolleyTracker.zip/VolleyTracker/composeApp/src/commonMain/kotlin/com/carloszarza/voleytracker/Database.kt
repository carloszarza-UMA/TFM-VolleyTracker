package com.carloszarza.volleytracker

import androidx.room.*
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import kotlinx.coroutines.flow.Flow

@Entity
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nombre: String,
    val fecha: String 
)

@Entity
data class SaltoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val dorsal: Int,
    val tipo: String,
    val altura: Int,
    val numeroSalto: Int
)

@Dao
interface SessionDao {
    @Insert
    suspend fun insertSession(session: SessionEntity): Long

    @Insert
    suspend fun insertSaltos(saltos: List<SaltoEntity>)

    @Query("SELECT * FROM SessionEntity ORDER BY id DESC")
    fun getAllSessions(): Flow<List<SessionEntity>>

    @Query("SELECT * FROM SaltoEntity WHERE sessionId = :sessionId ORDER BY numeroSalto ASC")
    suspend fun getSaltosBySession(sessionId: Long): List<SaltoEntity>

    @Delete
    suspend fun deleteSession(session: SessionEntity)
}

@Database(entities = [SessionEntity::class, SaltoEntity::class], version = 2)
@ConstructedBy(AppDatabaseConstructor::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao
}

@Suppress("KotlinNoActualForExpect")
expect object AppDatabaseConstructor : RoomDatabaseConstructor<AppDatabase> {
    override fun initialize(): AppDatabase
}

fun getRoomDatabase(
    builder: RoomDatabase.Builder<AppDatabase>
): AppDatabase {
    return builder
        .setDriver(BundledSQLiteDriver())
        .fallbackToDestructiveMigration(true)
        .build()
}
