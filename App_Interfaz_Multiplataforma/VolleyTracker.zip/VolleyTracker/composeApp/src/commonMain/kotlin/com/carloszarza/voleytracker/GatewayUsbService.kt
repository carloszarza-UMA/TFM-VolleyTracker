package com.carloszarza.volleytracker

import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

interface GatewayUsbService {
    val events: SharedFlow<GatewayEvent>

    val connectionState: StateFlow<GatewayConnectionState>

    suspend fun sendCommand(command: String)

    suspend fun startScan() = sendCommand("SCAN\n")
    suspend fun assignPlayer(mac: String, id: Int) = sendCommand("ASSIGN $mac $id\n")
    suspend fun startMatch() = sendCommand("START\n")
    suspend fun stopMatch() = sendCommand("STOP\n")
}

sealed class GatewayConnectionState {
    data object Disconnected : GatewayConnectionState()
    data class Connected(val gatewayMac: String) : GatewayConnectionState()
}
