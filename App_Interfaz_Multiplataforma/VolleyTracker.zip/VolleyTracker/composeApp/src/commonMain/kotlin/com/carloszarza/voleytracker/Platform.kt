package com.carloszarza.volleytracker

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform
