package com.carloszarza.volleytracker

expect object DateTimeProvider {
    fun getNowString(): String
}
