package com.carloszarza.volleytracker

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import volleytracker.composeapp.generated.resources.*

enum class Screen {
    Home,
    Scanning,
    Recording,
    SessionList
}

@Composable
fun SessionProvisioningApp(
    sessionViewModel: SessionViewModel,
    persistenceManager: FilePersistenceManager,
    database: AppDatabase,
    usbService: GatewayUsbService
) {
    var currentScreen by remember { mutableStateOf(Screen.Home) }
    val sessionState by sessionViewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    
    var recordingViewModel by remember { mutableStateOf<RecordingViewModel?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val lostConnectionMsg = stringResource(Res.string.lost_connection_msg)

    LaunchedEffect(sessionState.connectionState) {
        if (sessionState.connectionState is GatewayConnectionState.Disconnected) {
            if (currentScreen == Screen.Scanning || currentScreen == Screen.Recording) {
                val isReadOnly = recordingViewModel?.uiState?.value?.isReadOnly ?: false
                if (!isReadOnly) {
                    currentScreen = Screen.Home
                    errorMessage = lostConnectionMsg
                    recordingViewModel = null
                }
            }
        }
    }

    val gatewayNotFoundMsg = stringResource(Res.string.gateway_not_found_msg)
    val duplicateDorsalsError = stringResource(Res.string.duplicate_dorsals_error)

    when (currentScreen) {
        Screen.Home -> HomeScreen(
            onCreateSession = {
                if (sessionState.connectionState is GatewayConnectionState.Connected) {
                    sessionViewModel.reset()
                    currentScreen = Screen.Scanning
                    sessionViewModel.startScan()
                } else {
                    errorMessage = gatewayNotFoundMsg
                }
            },
            onReadSession = {
                currentScreen = Screen.SessionList
            }
        )
        Screen.SessionList -> SessionListScreen(
            database = database,
            onBack = { currentScreen = Screen.Home },
            onSessionClick = { session ->
                scope.launch {
                    val entities = database.sessionDao().getSaltosBySession(session.id)
                    val historicalSaltos = entities.map {
                        Salto(it.dorsal, it.altura, it.numeroSalto)
                    }
                    val rvm = RecordingViewModel(
                        dorsales = emptyList(), 
                        usbService = usbService,
                        isReadOnly = true, 
                        sessionId = session.id
                    )
                    rvm.loadHistoricalData(session.nombre, historicalSaltos)
                    recordingViewModel = rvm
                    currentScreen = Screen.Recording
                }
            }
        )
        Screen.Scanning -> ScanScreen(
            viewModel = sessionViewModel,
            onBack = { currentScreen = Screen.Home },
            onStartRecording = {
                val dorsales = sessionState.assignedDevices.values.toList()
                val distinctDorsales = dorsales.distinct()
                
                if (dorsales.size != distinctDorsales.size) {
                    errorMessage = duplicateDorsalsError
                } else {
                    sessionViewModel.startSessionSequence {
                        recordingViewModel = RecordingViewModel(
                            dorsales = dorsales,
                            usbService = usbService
                        )
                        currentScreen = Screen.Recording
                    }
                }
            }
        )
        Screen.Recording -> {
            recordingViewModel?.let { rvm ->
                RecordingScreen(
                    viewModel = rvm,
                    persistenceManager = persistenceManager,
                    database = database,
                    onStopRecording = {
                        currentScreen = Screen.Home
                        recordingViewModel = null
                    }
                )
            }
        }
    }

    errorMessage?.let { msg ->
        AlertDialog(
            onDismissRequest = { errorMessage = null },
            title = { Text(stringResource(Res.string.system_notice)) },
            text = { Text(msg) },
            confirmButton = {
                Button(onClick = { errorMessage = null }) {
                    Text(stringResource(Res.string.understood))
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SessionListScreen(
    database: AppDatabase,
    onBack: () -> Unit,
    onSessionClick: (SessionEntity) -> Unit
) {
    val sessions by database.sessionDao().getAllSessions().collectAsState(initial = emptyList())
    var sessionToDelete by remember { mutableStateOf<SessionEntity?>(null) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(Res.string.back_label)) }
            Spacer(modifier = Modifier.width(8.dp))
            Text(stringResource(Res.string.saved_sessions), style = MaterialTheme.typography.headlineSmall)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (sessions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(Res.string.no_saved_sessions), color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sessions) { session ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = { onSessionClick(session) },
                                onLongClick = { sessionToDelete = session }
                            ),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        )
                    ) {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text(session.nombre) },
                            supportingContent = { Text(stringResource(Res.string.date_label, session.fecha)) }
                        )
                    }
                }
            }
        }
    }

    sessionToDelete?.let { session ->
        AlertDialog(
            onDismissRequest = { sessionToDelete = null },
            title = { Text(stringResource(Res.string.delete_session_title)) },
            text = { Text(stringResource(Res.string.delete_session_msg, session.nombre)) },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        scope.launch {
                            database.sessionDao().deleteSession(session)
                            sessionToDelete = null
                        }
                    }
                ) { Text(stringResource(Res.string.delete), color = MaterialTheme.colorScheme.onError) }
            },
            dismissButton = {
                TextButton(onClick = { sessionToDelete = null }) { Text(stringResource(Res.string.cancel)) }
            }
        )
    }
}

@Composable
fun HomeScreen(onCreateSession: () -> Unit, onReadSession: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        Text(
            stringResource(Res.string.app_title), 
            fontSize = 24.sp, 
            fontWeight = FontWeight.Bold, 
            color = Color.Black,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 60.dp)
        )
        
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = onCreateSession,
                modifier = Modifier.fillMaxWidth(0.8f).height(60.dp)
            ) {
                Text(stringResource(Res.string.create_new_session))
            }
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedButton(
                onClick = onReadSession,
                modifier = Modifier.fillMaxWidth(0.8f).height(60.dp)
            ) {
                Text(stringResource(Res.string.view_saved_sessions))
            }
        }
    }
}

@Composable
fun ScanScreen(
    viewModel: SessionViewModel, 
    onBack: () -> Unit,
    onStartRecording: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var selectedMacForAssignment by remember { mutableStateOf<String?>(null) }
    var selectedMacForEdit by remember { mutableStateOf<Pair<String, Int>?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text(stringResource(Res.string.back_label)) }
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(Res.string.device_scanning), style = MaterialTheme.typography.headlineSmall)
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (state.isScanning) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(stringResource(Res.string.searching_devices), style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(stringResource(Res.string.detected_devices), fontWeight = FontWeight.Bold)
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(state.detectedMacs) { mac ->
                    Card(
                        onClick = { selectedMacForAssignment = mac },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        )
                    ) {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            headlineContent = { Text(mac) },
                            supportingContent = { Text(stringResource(Res.string.tap_to_assign)) }
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            Text(stringResource(Res.string.assigned_devices), fontWeight = FontWeight.Bold)
            LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(state.assignedDevices.toList()) { (mac, dorsal) ->
                    ListItem(
                        headlineContent = { Text(stringResource(Res.string.player_label, dorsal.toString())) },
                        supportingContent = { Text(stringResource(Res.string.mac_label, mac)) },
                        trailingContent = {
                            Row {
                                TextButton(onClick = { selectedMacForEdit = mac to dorsal }) {
                                    Text(stringResource(Res.string.edit))
                                }
                                TextButton(onClick = { viewModel.removeAssignedDevice(mac) }) {
                                    Text(stringResource(Res.string.delete), color = DarkGrayText)
                                }
                            }
                        }
                    )
                }
            }

            Button(
                onClick = onStartRecording,
                enabled = state.assignedDevices.isNotEmpty() && !state.isInitializing,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(stringResource(Res.string.start_recording))
            }
        }

        if (state.connectionState is GatewayConnectionState.Connected) {
            Surface(
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                color = Color.Red,
                shape = MaterialTheme.shapes.small,
                tonalElevation = 2.dp
            ) {
                Text(
                    text = stringResource(Res.string.gateway_label, (state.connectionState as GatewayConnectionState.Connected).gatewayMac),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White
                )
            }
        }

        if (state.isInitializing) {
            Dialog(
                onDismissRequest = {},
                properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
            ) {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            stringResource(Res.string.starting_session),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            stringResource(Res.string.syncing_sensors),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    selectedMacForAssignment?.let { mac ->
        PlayerAssignmentDialog(
            mac = mac,
            onDismiss = { selectedMacForAssignment = null },
            onConfirm = { playerNumber ->
                viewModel.assignPlayerNumber(mac, playerNumber)
                selectedMacForAssignment = null
            }
        )
    }

    selectedMacForEdit?.let { (mac, dorsal) ->
        PlayerAssignmentDialog(
            mac = mac,
            initialValue = dorsal.toString(),
            title = stringResource(Res.string.edit_dorsal),
            onDismiss = { selectedMacForEdit = null },
            onConfirm = { playerNumber ->
                viewModel.editPlayerNumber(mac, playerNumber)
                selectedMacForEdit = null
            }
        )
    }
}

@Composable
fun PlayerAssignmentDialog(
    mac: String, 
    initialValue: String = "",
    title: String = stringResource(Res.string.assign_dorsal),
    onDismiss: () -> Unit, 
    onConfirm: (Int) -> Unit
) {
    var playerNumber by remember { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(stringResource(Res.string.device_label, mac))
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = playerNumber,
                    onValueChange = { if (it.all { char -> char.isDigit() }) playerNumber = it },
                    label = { Text(stringResource(Res.string.player_number)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                enabled = playerNumber.isNotEmpty(),
                onClick = { onConfirm(playerNumber.toInt()) }
            ) {
                Text(stringResource(Res.string.confirm))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(Res.string.cancel)) }
        }
    )
}
