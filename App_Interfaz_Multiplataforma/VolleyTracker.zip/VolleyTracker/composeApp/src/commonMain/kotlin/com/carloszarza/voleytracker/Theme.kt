package com.carloszarza.volleytracker

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkRed = Color(0xFF8B0000)
val LightBeige = Color(0xFFFAF3E0)
val DarkGrayText = Color(0xFF444444)

private val LightColorScheme = lightColorScheme(
    primary = DarkRed,
    onPrimary = Color.White,
    secondary = DarkRed,
    onSecondary = Color.White,
    background = LightBeige,
    surface = LightBeige,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFE8E1D0),
    onSurfaceVariant = Color(0xFF49454F)
)

@Composable
fun VolleyTrackerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
