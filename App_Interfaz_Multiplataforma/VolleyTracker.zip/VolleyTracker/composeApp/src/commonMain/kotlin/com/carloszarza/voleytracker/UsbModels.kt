package com.carloszarza.volleytracker

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class GatewayJson(
    val status: String? = null,
    val event: String? = null,
    val mac: String? = null,
    val id: Int? = null,
    @SerialName("h") val h: Int? = null
)

sealed class GatewayEvent {
    data object ScannerOn : GatewayEvent()
    data class NewNode(val mac: String) : GatewayEvent()
    data class Assigned(val id: Int) : GatewayEvent()
    data object Started : GatewayEvent()
    data object Stopped : GatewayEvent()
    data class Jump(val playerId: Int, val height: Int) : GatewayEvent()
    data class Error(val message: String) : GatewayEvent()
}

val usbJson = Json { 
    ignoreUnknownKeys = true 
    coerceInputValues = true
}
