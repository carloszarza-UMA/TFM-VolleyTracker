package com.carloszarza.volleytracker

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import volleytracker.composeapp.generated.resources.*
import kotlin.math.pow
import kotlin.math.sqrt

@Composable
fun RecordingScreen(
    viewModel: RecordingViewModel, 
    persistenceManager: FilePersistenceManager,
    database: AppDatabase,
    onStopRecording: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var showSaveDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onStopRecording) {
                Text(stringResource(Res.string.back_label))
            }
            
            Spacer(modifier = Modifier.width(8.dp))

            val title = if (state.isReadOnly) stringResource(Res.string.historical_session) else stringResource(Res.string.live_recording)
            Text(
                text = title, 
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f)
            )
            
            if (state.isReadOnly) {
                Button(
                    onClick = {
                        scope.launch {
                            val csvData = viewModel.convertListToCsv()
                            val fileName = if (state.sessionName.isNotBlank()) state.sessionName else "export_${state.sessionId}"
                            persistenceManager.saveSession(fileName, csvData)
                        }
                    }
                ) {
                    Text(stringResource(Res.string.export_csv))
                }
            } else {
                Button(
                    onClick = {
                        viewModel.stopRecording()
                        showSaveDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(stringResource(Res.string.stop))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (state.isReadOnly && state.sessionName.isNotBlank()) {
            Text(
                text = stringResource(Res.string.session_label, state.sessionName),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp, start = 8.dp)
            )
        }

        val dorsales = if (state.isReadOnly) state.saltos.map { it.dorsal }.distinct() else viewModel.dorsales
        
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(dorsales) { dorsal ->
                PlayerRecordingCard(
                    dorsal = dorsal,
                    saltos = state.saltos.filter { it.dorsal == dorsal }
                )
            }
        }
    }

    if (showSaveDialog) {
        SaveSessionDialog(
            onDismiss = { 
                showSaveDialog = false
                onStopRecording()
            },
            onSave = { fileName ->
                scope.launch {
                    viewModel.saveToDatabase(database, fileName)
                    showSaveDialog = false
                    onStopRecording()
                }
            }
        )
    }
}

@Composable
fun SaveSessionDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var fileName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(Res.string.save_session_title)) },
        text = {
            Column {
                Text(stringResource(Res.string.enter_session_name))
                TextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(Res.string.session_name_placeholder)) }
                )
            }
        },
        confirmButton = {
            Button(enabled = fileName.isNotBlank(), onClick = { onSave(fileName) }) {
                Text(stringResource(Res.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(Res.string.discard)) }
        }
    )
}

@Composable
fun PlayerRecordingCard(
    dorsal: Int,
    saltos: List<Salto>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(Res.string.player_label, dorsal), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(stringResource(Res.string.total_jumps, saltos.size), fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(8.dp))

            SaltoChartComponent(
                saltos = saltos,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.height(250.dp).fillMaxWidth()
            )
        }
    }
}

@OptIn(ExperimentalTextApi::class)
@Composable
fun SaltoChartComponent(
    saltos: List<Salto>,
    color: Color,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val density = LocalDensity.current
    val stepWidthPx = with(density) { 40.dp.toPx() }
    val marginPx = with(density) { 32.dp.toPx() }
    val textMeasurer = rememberTextMeasurer()
    var selectedSalto by remember { mutableStateOf<Pair<Salto, Offset>?>(null) }
    val chartBgColor = MaterialTheme.colorScheme.surface

    LaunchedEffect(scrollState.maxValue) {
        if (saltos.isNotEmpty() && (scrollState.value >= scrollState.maxValue - stepWidthPx.toInt() * 2 || scrollState.value == 0)) {
            scrollState.animateScrollTo(scrollState.maxValue)
        }
    }

    Box(modifier = modifier.background(chartBgColor).horizontalScroll(scrollState)) {
        val totalSteps = saltos.maxOfOrNull { it.numeroSalto } ?: 0
        val canvasWidth = with(density) { (totalSteps * 40 + 64).dp }

        Canvas(
            modifier = Modifier
                .width(canvasWidth)
                .fillMaxHeight()
                .padding(vertical = 20.dp)
                .pointerInput(saltos) {
                    detectTapGestures { offset ->
                        val height = size.height
                        if (saltos.isEmpty()) return@detectTapGestures

                        val maxY = saltos.maxOfOrNull { it.alturaCm.toFloat() }?.coerceAtLeast(130f) ?: 130f
                        val closest = saltos.map { s ->
                            val x = (s.numeroSalto - 1) * stepWidthPx + marginPx
                            val y = height - (s.alturaCm / maxY * height)
                            s to Offset(x, y)
                        }.minByOrNull { (_, pos) ->
                            sqrt((pos.x - offset.x).pow(2) + (pos.y - offset.y).pow(2))
                        }

                        selectedSalto = if (closest != null && sqrt((closest.second.x - offset.x).pow(2) + (closest.second.y - offset.y).pow(2)) < 40f) {
                            closest
                        } else null
                    }
                }
        ) {
            val width = size.width
            val height = size.height
            val maxY = saltos.maxOfOrNull { it.alturaCm.toFloat() }?.coerceAtLeast(130f) ?: 130f

            drawLine(color = Color.LightGray, start = Offset(0f, height), end = Offset(width, height), strokeWidth = 2f)
            for (i in 0..maxY.toInt() step 20) {
                val yPos = height - (i / maxY * height)
                drawLine(color = Color.Black.copy(0.05f), start = Offset(0f, yPos), end = Offset(width, yPos), strokeWidth = 1f)
            }

            if (saltos.isNotEmpty()) {
                val path = Path()
                saltos.sortedBy { it.numeroSalto }.forEachIndexed { index, salto ->
                    val x = (salto.numeroSalto - 1) * stepWidthPx + marginPx
                    val y = height - (salto.alturaCm / maxY * height)
                    val pos = Offset(x, y)

                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    drawCircle(color, 4.dp.toPx(), pos)
                }
                drawPath(path, color, style = Stroke(2.dp.toPx()))
            }

            selectedSalto?.let { (salto, pos) ->
                val tooltipText = "${salto.alturaCm}cm (#${salto.numeroSalto})"
                val textLayout = textMeasurer.measure(tooltipText, TextStyle(fontSize = 12.sp, color = Color.White))
                val tw = textLayout.size.width + 24f
                val th = textLayout.size.height + 12f
                
                val tooltipOffset = Offset(
                    x = (pos.x - tw / 2).coerceIn(0f, width - tw),
                    y = (pos.y - th - 20f).coerceAtLeast(0f)
                )

                drawRoundRect(color = Color.Black.copy(alpha = 0.8f), topLeft = tooltipOffset, size = Size(tw, th), cornerRadius = CornerRadius(4.dp.toPx()))
                drawText(textLayoutResult = textLayout, topLeft = Offset(tooltipOffset.x + 12f, tooltipOffset.y + 6f))
                drawLine(color = Color.Gray, start = pos, end = Offset(pos.x, height), strokeWidth = 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
            }
        }
    }
}
