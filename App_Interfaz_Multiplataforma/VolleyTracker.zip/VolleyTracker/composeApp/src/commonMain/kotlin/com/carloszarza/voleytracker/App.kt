package com.carloszarza.volleytracker

import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.tooling.preview.Preview

@Composable
@Preview
fun App(databaseBuilderFactory: DatabaseBuilderFactory) {
    VolleyTrackerTheme {
        Surface {
            val persistenceManager = remember { getPlatformPersistenceManager() }
            val database = remember { getRoomDatabase(databaseBuilderFactory.create()) }
            
            val usbService = remember { getPlatformUsbService() }
            
            val sessionViewModel = remember { SessionViewModel(usbService) }
            
            SessionProvisioningApp(sessionViewModel, persistenceManager, database, usbService)
        }
    }
}

expect fun getPlatformUsbService(): GatewayUsbService
