package com.carloszarza.volleytracker

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

data class RecordingUiState(
    val saltos: List<Salto> = emptyList(),
    val isRecording: Boolean = false,
    val isReadOnly: Boolean = false,
    val sessionId: Long? = null,
    val sessionName: String = ""
)

class RecordingViewModel(
    val dorsales: List<Int>,
    private val usbService: GatewayUsbService,
    isReadOnly: Boolean = false,
    sessionId: Long? = null
) {
    private val _uiState = MutableStateFlow(RecordingUiState(isReadOnly = isReadOnly, sessionId = sessionId))
    val uiState: StateFlow<RecordingUiState> = _uiState.asStateFlow()

    private val viewModelScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    init {
        if (!isReadOnly) {
            viewModelScope.launch {
                usbService.events.collect { event ->
                    when (event) {
                        is GatewayEvent.Jump -> {
                            handleNewJump(event.playerId, event.height)
                        }
                        is GatewayEvent.Started -> {
                            _uiState.update { it.copy(isRecording = true) }
                        }
                        is GatewayEvent.Stopped -> {
                            _uiState.update { it.copy(isRecording = false) }
                        }
                        else -> { }
                    }
                }
            }
        }
    }

    private fun handleNewJump(playerId: Int, height: Int) {
        _uiState.update { state ->
            val num = state.saltos.count { it.dorsal == playerId } + 1
            state.copy(saltos = state.saltos + Salto(playerId, height, num))
        }
    }

    fun startRecording() {
        if (_uiState.value.isReadOnly) return
        viewModelScope.launch {
            usbService.startMatch()
        }
    }

    fun stopRecording() {
        if (_uiState.value.isReadOnly) return
        viewModelScope.launch {
            usbService.stopMatch()
        }
    }

    fun loadHistoricalData(sessionName: String, historicalSaltos: List<Salto>) {
        _uiState.update { it.copy(sessionName = sessionName, saltos = historicalSaltos) }
    }

    suspend fun saveToDatabase(database: AppDatabase, nombre: String) {
        val timestamp = DateTimeProvider.getNowString()
        val sessionId = database.sessionDao().insertSession(
            SessionEntity(nombre = nombre, fecha = timestamp)
        )
        val saltoEntities = _uiState.value.saltos.map {
            SaltoEntity(
                sessionId = sessionId,
                dorsal = it.dorsal,
                tipo = "GENERAL",
                altura = it.alturaCm,
                numeroSalto = it.numeroSalto
            )
        }
        database.sessionDao().insertSaltos(saltoEntities)
        _uiState.update { it.copy(sessionName = nombre) }
    }

    fun convertListToCsv(): String {
        val header = "Dorsal,Altura,NumeroSalto\n"
        val body = _uiState.value.saltos.joinToString("\n") {
            "${it.dorsal},${it.alturaCm},${it.numeroSalto}"
        }
        return header + body
    }

    companion object {
        fun parseCsvToList(csv: String): List<Salto> {
            val lines = csv.lines()
            if (lines.size <= 1) return emptyList()
            
            return lines.drop(1).filter { it.isNotBlank() }.map { line ->
                val parts = line.split(",")
                Salto(
                    dorsal = parts[0].toInt(),
                    alturaCm = parts[1].toInt(),
                    numeroSalto = parts[2].toInt()
                )
            }
        }
    }
}
