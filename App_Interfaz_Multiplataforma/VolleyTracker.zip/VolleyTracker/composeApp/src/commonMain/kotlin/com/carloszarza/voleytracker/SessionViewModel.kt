package com.carloszarza.volleytracker

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SessionUiState(
    val detectedMacs: List<String> = emptyList(),
    val assignedDevices: Map<String, Int> = emptyMap(),
    val isScanning: Boolean = false,
    val connectionState: GatewayConnectionState = GatewayConnectionState.Disconnected,
    val isInitializing: Boolean = false
)

class SessionViewModel(private val usbService: GatewayUsbService) {
    private val _uiState = MutableStateFlow(SessionUiState())
    val uiState: StateFlow<SessionUiState> = _uiState.asStateFlow()

    private val viewModelScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        viewModelScope.launch {
            usbService.connectionState.collect { state ->
                _uiState.update { it.copy(connectionState = state) }
            }
        }

        viewModelScope.launch {
            usbService.events.collect { event ->
                when (event) {
                    is GatewayEvent.NewNode -> {
                        _uiState.update { currentState ->
                            if (!currentState.detectedMacs.contains(event.mac) && !currentState.assignedDevices.containsKey(event.mac)) {
                                currentState.copy(detectedMacs = currentState.detectedMacs + event.mac)
                            } else {
                                currentState
                            }
                        }
                    }
                    is GatewayEvent.ScannerOn -> {
                        _uiState.update { it.copy(isScanning = true) }
                    }
                    else -> {}
                }
            }
        }
    }

    fun reset() {
        _uiState.update { 
            it.copy(
                detectedMacs = emptyList(),
                assignedDevices = emptyMap(),
                isScanning = false,
                isInitializing = false
            )
        }
    }

    fun startScan() {
        viewModelScope.launch {
            try {
                usbService.startScan()
            } catch (e: Exception) {
                println("Error al iniciar escaneo: ${e.message}")
            }
        }
    }

    fun assignPlayerNumber(mac: String, playerNumber: Int) {
        _uiState.update { currentState ->
            currentState.copy(
                assignedDevices = currentState.assignedDevices + (mac to playerNumber),
                detectedMacs = currentState.detectedMacs - mac
            )
        }
    }

    fun removeAssignedDevice(mac: String) {
        _uiState.update { currentState ->
            currentState.copy(
                assignedDevices = currentState.assignedDevices - mac,
                detectedMacs = currentState.detectedMacs + mac
            )
        }
    }

    fun editPlayerNumber(mac: String, newPlayerNumber: Int) {
        _uiState.update { currentState ->
            currentState.copy(
                assignedDevices = currentState.assignedDevices + (mac to newPlayerNumber)
            )
        }
    }

    fun startSessionSequence(onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isInitializing = true) }
                val devices = _uiState.value.assignedDevices
                for ((mac, id) in devices) {
                    usbService.assignPlayer(mac, id)
                    delay(1000)
                }
                usbService.startMatch()
                delay(1000)
                _uiState.update { it.copy(isInitializing = false) }
                onComplete()
            } catch (e: Exception) {
                _uiState.update { it.copy(isInitializing = false) }
            }
        }
    }
}
